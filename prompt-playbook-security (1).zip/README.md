# Prompt Playbook for Security Teams

This project is a prompt engineering library focused on cybersecurity use cases.
It contains templates and sample outputs to support structured, repeatable LLM prompting.
